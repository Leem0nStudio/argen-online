// ============================================================
// Socket Handlers — Wire socket events to game modules
// ============================================================

import type { Server, Socket } from "socket.io";
import type { ClientEvents, ServerEvents } from "../../shared/types.js";
import { Direction } from "../../shared/types.js";
import { ITEMS } from "../../shared/items.js";
import {
  registerPlayer, authenticatePlayer, getPlayer as getDbPlayer,
  savePlayer, saveInventory, saveEquipment,
} from "../db/database.js";
import {
  Players, Ground, SpawnState,
} from "../game/state.js";
import {
  movePlayer, stopPlayer, respawnPlayer,
} from "../game/movement.js";
import { tryAttack, grantXp } from "../game/combat.js";
import { useSkill } from "../game/skills.js";
import { pickupItem, equipItem, useConsumable } from "../game/inventory.js";
import { addChatMessage, addSystemMessage } from "../game/chat.js";
import { getNPC, npcBuyItem, npcSellItem } from "../game/npc.js";
import { spawnMonstersForMap, getMonstersAsData } from "../game/monster-ai.js";
import { getWorldMap, getWorldDataForClient } from "../game/world.js";
import { getPlayersOnMap } from "./helpers.js";

type GameServer = Server<ClientEvents, ServerEvents>;
type GameSocket = Socket<ClientEvents, ServerEvents>;

function ensureMonsters(mapId: string) {
  if (!SpawnState.hasSpawned(mapId)) {
    spawnMonstersForMap(mapId);
    SpawnState.markSpawned(mapId);
  }
}

function sendMapState(socket: GameSocket, mapId: string) {
  const player = Players.get(socket.data.playerId!);
  if (!player) return;
  socket.join(mapId);
  ensureMonsters(mapId);
  socket.emit("world:state", {
    players: getPlayersOnMap(mapId),
    groundItems: Ground.onMap(mapId),
    mapId,
  });
  socket.emit("monsters:update", getMonstersAsData(mapId));
  // Send procedural world data to client
  try {
    socket.emit("world:data", getWorldDataForClient());
  } catch { /* world not ready */ }
}

export function setupHandlers(io: GameServer) {
  io.on("connection", (socket: GameSocket) => {
    console.log(`[Socket] Connected: ${socket.id}`);

    socket.on("auth:register", (data) => {
      try {
        const id = registerPlayer(data.username, data.password, data.characterClass);
        const player = getDbPlayer(id);
        if (!player) {
          socket.emit("auth:error", "Error al crear personaje");
          return;
        }
        Players.set(player);
        socket.data.playerId = id;
        socket.emit("auth:success", player);
        sendMapState(socket, player.mapId);
        io.emit("players:list", getPlayersOnMap(player.mapId));
        io.emit("chat:message", addSystemMessage(`${player.username} ha entrado al mundo.`));
      } catch (err: any) {
        socket.emit("auth:error", err.message?.includes("UNIQUE") ? "Nombre ya existe" : "Error al registrar");
      }
    });

    socket.on("auth:login", (data) => {
      const playerId = authenticatePlayer(data.username, data.password);
      if (!playerId) {
        socket.emit("auth:error", "Usuario o contraseña incorrectos");
        return;
      }
      const player = getDbPlayer(playerId);
      if (!player) {
        socket.emit("auth:error", "Error al cargar personaje");
        return;
      }
      Players.set(player);
      socket.data.playerId = playerId;
      socket.emit("auth:success", player);
      sendMapState(socket, player.mapId);
      io.emit("players:list", getPlayersOnMap(player.mapId));
      io.emit("chat:message", addSystemMessage(`${player.username} ha regresado.`));
    });

    socket.on("player:move", (data) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      const result = movePlayer(playerId, data.x, data.y, data.direction);
      if (!result) return;

      if (result.teleported) {
        const player = Players.get(playerId);
        if (player) {
          sendMapState(socket, player.mapId);
          io.emit("players:list", getPlayersOnMap(player.mapId));
        }
      } else {
        const player = Players.get(playerId);
        if (player) {
          socket.to(player.mapId).emit("player:move", {
            id: playerId, x: data.x, y: data.y, direction: data.direction, isMoving: true,
          });
        }
      }
    });

    socket.on("player:stop", (data) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      stopPlayer(playerId, data.x, data.y, data.direction);
      const player = Players.get(playerId);
      if (player) {
        socket.to(player.mapId).emit("player:move", {
          id: playerId, x: data.x, y: data.y, direction: data.direction, isMoving: false,
        });
      }
    });

    socket.on("chat:send", (message) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      const player = Players.get(playerId);
      if (!player) return;
      const msg = addChatMessage(playerId, player.username, message);
      io.emit("chat:message", msg);
    });

    socket.on("combat:attack", (targetId) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      const event = tryAttack(playerId, targetId);
      if (!event) return;
      io.emit("combat:damage", event);

      const victim = Players.get(targetId);
      const monster = Monsters.get(targetId);
      if (victim && victim.stats.hp <= 0) {
        io.emit("combat:death", { killerId: playerId, victimId: targetId });
        const killer = Players.get(playerId);
        io.emit("chat:message", addSystemMessage(`${killer?.username} ha derrotado a ${victim.username}!`));
      }
      // XP from monster kill
      if (monster && monster.hp <= 0) {
        const killer = Players.get(playerId);
        if (killer) {
          const xpResult = grantXp(killer, monster.xpReward);
          io.emit("combat:damage", { attackerId: playerId, defenderId: targetId, damage: 0, isCrit: false, timestamp: Date.now(), xp: monster.xpReward });
          if (xpResult.leveledUp) {
            socket.emit("player:levelup", { level: xpResult.newLevel, statPoints: xpResult.totalStatPoints, newUnlocks: xpResult.newUnlocks });
            io.emit("chat:message", addSystemMessage(`¡${killer.username} ha subido al nivel ${xpResult.newLevel}!`));
          }
        }
      }

      const attacker = Players.get(playerId);
      if (attacker) socket.emit("player:update", attacker);
    });

    socket.on("skill:use", (data) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      const event = useSkill(playerId, data.skillId, data.targetId);
      if (!event) return;

      io.emit("skill:effect", event);

      if (event.damage && event.damage > 0 && event.targetId) {
        io.emit("combat:damage", {
          attackerId: playerId, defenderId: event.targetId,
          damage: event.damage, isCrit: false, timestamp: Date.now(),
        });
      }

      if (event.aoe && event.damage) {
        io.emit("combat:damage", {
          attackerId: playerId, defenderId: playerId,
          damage: 0, isCrit: false, timestamp: Date.now(),
        });
      }

      const player = Players.get(playerId);
      if (player) socket.emit("player:update", player);
    });

    socket.on("item:pickup", (groundItemId) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      if (pickupItem(playerId, groundItemId)) {
        const player = Players.get(playerId);
        if (player) {
          socket.emit("player:update", player);
          io.emit("groundItems:update", Ground.onMap(player.mapId));
        }
      }
    });

    socket.on("item:equip", (inventorySlot) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      if (equipItem(playerId, inventorySlot)) {
        const player = Players.get(playerId);
        if (player) socket.emit("player:update", player);
      }
    });

    socket.on("item:use", (inventorySlot) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      if (useConsumable(playerId, inventorySlot)) {
        const player = Players.get(playerId);
        if (player) {
          socket.emit("player:update", player);
          socket.emit("combat:damage", {
            attackerId: playerId, defenderId: playerId,
            damage: 0, isCrit: false, timestamp: Date.now(),
          });
        }
      }
    });

    socket.on("item:drop", (inventorySlot, quantity) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      const player = Players.get(playerId);
      if (player) socket.emit("player:update", player);
    });

    socket.on("npc:interact", (npcId) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      const player = Players.get(playerId);
      if (!player) return;
      const npc = getNPC(player.mapId, npcId);
      if (!npc) return;
      const dialogue = npc.dialogue[Math.floor(Math.random() * npc.dialogue.length)];
      const shopItems = npc.shopItems?.map(id => ITEMS[id]).filter(Boolean);
      socket.emit("npc:interact", { npcId, dialogue, shopItems });
    });

    socket.on("npc:buy", (itemId, quantity) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      if (npcBuyItem(playerId, itemId, quantity)) {
        const player = Players.get(playerId);
        if (player) socket.emit("player:update", player);
      }
    });

    socket.on("npc:sell", (inventorySlot, quantity) => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      if (npcSellItem(playerId, inventorySlot, quantity)) {
        const player = Players.get(playerId);
        if (player) socket.emit("player:update", player);
      }
    });

    socket.on("player:respawn", () => {
      const playerId = socket.data.playerId;
      if (!playerId) return;
      respawnPlayer(playerId);
      const player = Players.get(playerId);
      if (player) {
        socket.emit("auth:success", player);
        sendMapState(socket, player.mapId);
        io.emit("players:list", getPlayersOnMap(player.mapId));
      }
    });

    // ---- Procedural world chunk streaming ----
    socket.on("world:request", (data) => {
      try {
        const wm = getWorldMap();
        const radiusChunks = Math.max(1, Math.min(3, Math.ceil((data.radius ?? 40) / 64)));
        const { rx: prx, ry: pry } = wm.chunkCoordsAt(data.wx, data.wy);
        for (let ry = pry - radiusChunks; ry <= pry + radiusChunks; ry++) {
          for (let rx = prx - radiusChunks; rx <= prx + radiusChunks; rx++) {
            if (!wm.isChunkInBounds(rx, ry)) continue;
            const tiles = wm.getChunkTiles(rx * 64 + 32, ry * 64 + 32);
            socket.emit("world:chunk", { rx, ry, tiles });
          }
        }
      } catch (err) {
        console.error("[Socket] world:request failed:", err);
      }
    });

    // ---- Stat Allocation ----
    socket.on("stat:allocate", (data) => {
      const playerId = socket.data.playerId;
      const player = playerId ? Players.get(playerId) : undefined;
      if (!player || player.statPoints <= 0) return;

      const stat = data.stat;
      if (!player.stats[stat] && player.stats[stat] !== 0) return;

      (player.stats as Record<string, number>)[stat] += 1;
      player.statPoints -= 1;

      // Recalculate derived stats
      if (stat === "constitution") {
        player.stats.maxHp += 3;
        player.stats.hp = Math.min(player.stats.hp + 3, player.stats.maxHp);
      } else if (stat === "intelligence") {
        player.stats.maxMp += 2;
        player.stats.mp = Math.min(player.stats.mp + 2, player.stats.maxMp);
      }

      socket.emit("player:update", player);
    });

    socket.on("disconnect", () => {
      const playerId = socket.data.playerId;
      if (playerId) {
        const player = Players.get(playerId);
        if (player) {
          io.to(player.mapId).emit("player:leave", playerId);
          io.emit("chat:message", addSystemMessage(`${player.username} ha salido del mundo.`));
        }
        // Save before removing
        const removed = Players.delete(playerId);
        if (removed) {
          savePlayer(removed);
          saveInventory(playerId, removed.inventory);
          saveEquipment(playerId, removed.equipment as Record<string, string | null>);
        }
      }
      console.log(`[Socket] Disconnected: ${socket.id}`);
    });
  });
}
